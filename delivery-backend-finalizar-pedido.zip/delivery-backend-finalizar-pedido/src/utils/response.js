const createResponse = (success, message, data = null, statusCode = 200) => {
  const response = {
    success,
    message,
    timestamp: new Date().toISOString()
  };

  if (data) {
    response.data = data;
  }

  return {
    statusCode,
    body: response
  };
};

module.exports = {
  success: (message, data) => createResponse(true, message, data, 200),
  created: (message, data) => createResponse(true, message, data, 201),
  badRequest: (message, data) => createResponse(false, message, data, 400),
  unauthorized: (message) => createResponse(false, message, null, 401),
  forbidden: (message) => createResponse(false, message, null, 403),
  notFound: (message) => createResponse(false, message, null, 404),
  serverError: (message) => createResponse(false, message || 'Internal server error', null, 500)
};