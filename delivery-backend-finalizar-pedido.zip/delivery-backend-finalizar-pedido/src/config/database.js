const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('20252_prjint5', '20252_prjint5', 'Senac@2025', {
  host: 'edumysql.acesso.rj.senac.br',
  dialect: 'mysql',
  logging: true, // Ativando logs para debug
  define: {
    timestamps: true,
    underscored: true,
  },
  pool: {
    max: 5, // número máximo de conexões no pool
    min: 0, // número mínimo de conexões no pool
    acquire: 30000, // tempo máximo, em milissegundos, que o pool tentará se conectar antes de lançar erro
    idle: 10000 // tempo máximo, em milissegundos, que uma conexão pode ficar inativa antes de ser liberada
  },
  dialectOptions: {
    connectTimeout: 60000,
    timezone: '-03:00',
    ssl: false
  }
});

module.exports = sequelize;