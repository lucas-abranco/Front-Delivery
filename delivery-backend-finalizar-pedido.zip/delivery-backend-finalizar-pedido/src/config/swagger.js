const swaggerJsdoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'API de Delivery',
      version: '1.0.0',
      description: 'API para sistema de delivery com gerenciamento de pedidos e pagamentos',
      contact: {
        name: 'Suporte',
        email: 'suporte@delivery.com'
      }
    },
    servers: [
      {
        url: 'http://localhost:3000/api/v1',
        description: 'Servidor de Desenvolvimento'
      }
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT'
        }
      }
    },
    security: [{
      bearerAuth: []
    }]
  },
  apis: ['./src/routes/*.js', './src/models/*.js'], // arquivos a serem escaneados
};

const specs = swaggerJsdoc(options);

module.exports = specs;