require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const routes = require('./routes');
const healthRoutes = require('./routes/health');
const sequelize = require('./config/database');
const errorHandler = require('./middleware/errorHandler');
const corsOptions = require('./config/cors');
const sanitizeInput = require('./middleware/sanitize');
const timeout = require('./middleware/timeout');
const { requestLogger } = require('./utils/logger');

const app = express();

// Security middlewares
app.use(helmet({
  contentSecurityPolicy: true,
  crossOriginEmbedderPolicy: true,
  crossOriginOpenerPolicy: true,
  crossOriginResourcePolicy: true,
  dnsPrefetchControl: true,
  frameguard: true,
  hidePoweredBy: true,
  hsts: true,
  ieNoOpen: true,
  noSniff: true,
  originAgentCluster: true,
  permittedCrossDomainPolicies: true,
  referrerPolicy: true,
  xssFilter: true
}));
app.use(cors(corsOptions));

// Rate limiting
const limiter = rateLimit({
  windowMs: (process.env.RATE_LIMIT_WINDOW || 15) * 60 * 1000,
  max: process.env.RATE_LIMIT_MAX_REQUESTS || 100,
  message: 'Too many requests from this IP, please try again later.'
});

// Request parsing and security
app.use(express.json({ limit: '10kb' })); // Limita o tamanho do payload
app.use(express.urlencoded({ extended: true, limit: '10kb' }));
app.use(sanitizeInput);
app.use(timeout(30)); // 30 segundos de timeout

// Logging
app.use(morgan('dev'));
app.use(requestLogger);

// Health check route (não precisa de autenticação)
app.use('/health', healthRoutes);

// API routes
app.use('/api/v1', limiter, routes);

// Error handling
app.use(errorHandler);

const PORT = process.env.PORT || 3000;

async function startServer() {
  try {
    await sequelize.authenticate();
    console.log('Database connection has been established successfully.');
    

    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
}

startServer();