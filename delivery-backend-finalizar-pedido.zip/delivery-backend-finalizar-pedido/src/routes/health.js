const express = require('express');
const router = express.Router();
const sequelize = require('../config/database');

router.get('/health', async (req, res) => {
  try {
    // Verifica conexão com o banco de dados
    await sequelize.authenticate();

    const healthcheck = {
      uptime: process.uptime(),
      message: 'OK',
      timestamp: Date.now(),
      database: 'Connected',
      memoryUsage: process.memoryUsage(),
      nodeVersion: process.version
    };

    res.status(200).json(healthcheck);
  } catch (error) {
    res.status(503).json({
      uptime: process.uptime(),
      message: 'Service Unavailable',
      timestamp: Date.now(),
      database: 'Disconnected',
      error: error.message
    });
  }
});

module.exports = router;