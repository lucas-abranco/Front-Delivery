const timeout = (seconds) => {
  const milliseconds = seconds * 1000;

  return (req, res, next) => {
    res.setTimeout(milliseconds, () => {
      res.status(408).json({
        success: false,
        message: 'Request timeout'
      });
    });
    next();
  };
};

module.exports = timeout;