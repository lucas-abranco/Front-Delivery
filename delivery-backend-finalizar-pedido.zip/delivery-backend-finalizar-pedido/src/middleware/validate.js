const { validationResult } = require('express-validator');
const response = require('../utils/response');

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const { body } = response.badRequest('Validation error', {
      errors: errors.array().map(err => ({
        field: err.param,
        message: err.msg
      }))
    });
    return res.status(400).json(body);
  }
  next();
};

module.exports = validate;