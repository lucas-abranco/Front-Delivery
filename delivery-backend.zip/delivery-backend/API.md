# Delivery System API Documentation

## Authentication

### Register User
- **URL**: `/auth/register`
- **Method**: `POST`
- **Body**:
  ```json
  {
    "name": "string",
    "email": "string",
    "password": "string",
    "role": "customer|driver|admin"
  }
  ```
- **Success Response**: 
  - Status: 201
  ```json
  {
    "success": true,
    "user": {
      "id": "number",
      "name": "string",
      "email": "string",
      "role": "string"
    },
    "token": "string"
  }
  ```

### Login
- **URL**: `/auth/login`
- **Method**: `POST`
- **Body**:
  ```json
  {
    "email": "string",
    "password": "string"
  }
  ```
- **Success Response**: 
  - Status: 200
  ```json
  {
    "success": true,
    "user": {
      "id": "number",
      "name": "string",
      "email": "string",
      "role": "string"
    },
    "token": "string"
  }
  ```

## Orders

### Create Order
- **URL**: `/orders`
- **Method**: `POST`
- **Headers**: `Authorization: Bearer <token>`
- **Body**:
  ```json
  {
    "items": [
      {
        "productId": "number",
        "quantity": "number",
        "price": "number"
      }
    ],
    "deliveryAddress": "string",
    "paymentMethod": "credit_card|debit_card|pix",
    "total": "number"
  }
  ```
- **Success Response**: 
  - Status: 201
  ```json
  {
    "success": true,
    "orderId": "number",
    "message": "string"
  }
  ```

### Get Order
- **URL**: `/orders/:id`
- **Method**: `GET`
- **Headers**: `Authorization: Bearer <token>`
- **Success Response**: 
  - Status: 200
  ```json
  {
    "success": true,
    "order": {
      "id": "number",
      "status": "string",
      "total": "number",
      "items": []
    }
  }
  ```

### Update Order Status
- **URL**: `/orders/:id/status`
- **Method**: `PATCH`
- **Headers**: `Authorization: Bearer <token>`
- **Body**:
  ```json
  {
    "status": "pending|confirmed|preparing|in_delivery|delivered|cancelled"
  }
  ```
- **Success Response**: 
  - Status: 200
  ```json
  {
    "success": true,
    "message": "string",
    "order": {}
  }
  ```

## Payments

### Process Payment
- **URL**: `/payments`
- **Method**: `POST`
- **Headers**: `Authorization: Bearer <token>`
- **Body**:
  ```json
  {
    "orderId": "number",
    "paymentMethod": "credit_card|debit_card|pix",
    "paymentDetails": {
      "cardNumber": "string",
      "cardHolder": "string",
      "expirationDate": "string",
      "cvv": "string",
      "pixKey": "string"
    }
  }
  ```
- **Success Response**: 
  - Status: 200
  ```json
  {
    "success": true,
    "message": "string",
    "order": {
      "id": "number",
      "status": "string",
      "paymentStatus": "string"
    }
  }
  ```

## Error Responses

All endpoints may return the following error responses:

### Validation Error
- Status: 400
```json
{
  "success": false,
  "message": "string"
}
```

### Authentication Error
- Status: 401
```json
{
  "success": false,
  "message": "string"
}
```

### Not Found Error
- Status: 404
```json
{
  "success": false,
  "message": "string"
}
```

### Server Error
- Status: 500
```json
{
  "success": false,
  "message": "string",
  "error": "string"
}
```