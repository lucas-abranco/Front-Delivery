const yup = require('yup');

const orderSchema = yup.object().shape({
  items: yup.array().of(
    yup.object().shape({
      productId: yup.number().required('Product ID is required'),
      quantity: yup.number().required('Quantity is required').min(1),
      price: yup.number().required('Price is required').min(0)
    })
  ).required('Items are required').min(1, 'Order must contain at least one item'),
  deliveryAddress: yup.string().required('Delivery address is required'),
  paymentMethod: yup.string().oneOf(['credit_card', 'debit_card', 'pix'], 'Invalid payment method'),
  total: yup.number().required('Total is required').min(0)
});

module.exports = {
  validateOrder: (data) => {
    try {
      orderSchema.validateSync(data, { abortEarly: false });
      return { error: null };
    } catch (error) {
      return { error };
    }
  }
};