const yup = require('yup');

const userSchema = yup.object().shape({
  name: yup.string().required('Name is required').min(2, 'Name must be at least 2 characters'),
  email: yup.string().email('Invalid email').required('Email is required'),
  password: yup.string().required('Password is required').min(6, 'Password must be at least 6 characters'),
  role: yup.string().oneOf(['customer', 'driver', 'admin'], 'Invalid role')
});

const loginSchema = yup.object().shape({
  email: yup.string().email('Invalid email').required('Email is required'),
  password: yup.string().required('Password is required')
});

module.exports = {
  validateUser: (data) => {
    try {
      userSchema.validateSync(data, { abortEarly: false });
      return { error: null };
    } catch (error) {
      return { error };
    }
  },
  validateLogin: (data) => {
    try {
      loginSchema.validateSync(data, { abortEarly: false });
      return { error: null };
    } catch (error) {
      return { error };
    }
  }
};