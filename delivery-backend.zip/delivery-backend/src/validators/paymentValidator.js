const yup = require('yup');

const paymentSchema = yup.object().shape({
  orderId: yup.number().required('Order ID is required'),
  paymentMethod: yup.string().oneOf(['credit_card', 'debit_card', 'pix'], 'Invalid payment method'),
  paymentDetails: yup.object().shape({
    cardNumber: yup.string().when('paymentMethod', {
      is: (method) => ['credit_card', 'debit_card'].includes(method),
      then: yup.string().required('Card number is required').matches(/^[0-9]{16}$/, 'Invalid card number')
    }),
    cardHolder: yup.string().when('paymentMethod', {
      is: (method) => ['credit_card', 'debit_card'].includes(method),
      then: yup.string().required('Card holder name is required')
    }),
    expirationDate: yup.string().when('paymentMethod', {
      is: (method) => ['credit_card', 'debit_card'].includes(method),
      then: yup.string().required('Expiration date is required').matches(/^(0[1-9]|1[0-2])\/([0-9]{2})$/, 'Invalid expiration date')
    }),
    cvv: yup.string().when('paymentMethod', {
      is: (method) => ['credit_card', 'debit_card'].includes(method),
      then: yup.string().required('CVV is required').matches(/^[0-9]{3,4}$/, 'Invalid CVV')
    }),
    pixKey: yup.string().when('paymentMethod', {
      is: 'pix',
      then: yup.string().required('PIX key is required')
    })
  })
});

module.exports = {
  validatePayment: (data) => {
    try {
      paymentSchema.validateSync(data, { abortEarly: false });
      return { error: null };
    } catch (error) {
      return { error };
    }
  }
};