const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const orderController = require('../controllers/orderController');
const paymentController = require('../controllers/paymentController');
const authMiddleware = require('../middleware/auth');

// Auth routes
router.post('/auth/register', authController.register);
router.post('/auth/login', authController.login);

// Order routes
router.post('/orders', authMiddleware, orderController.create);
router.get('/orders/:id', authMiddleware, orderController.getOrderById);
router.patch('/orders/:id/status', authMiddleware, orderController.updateOrderStatus);

// Payment routes
router.post('/payments', authMiddleware, paymentController.processPayment);

module.exports = router;