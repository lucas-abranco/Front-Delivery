const Order = require('../models/Order');
const { validatePayment } = require('../validators/paymentValidator');

const paymentController = {
  async processPayment(req, res) {
    try {
      // Validate input
      const { error } = validatePayment(req.body);
      if (error) {
        return res.status(400).json({
          success: false,
          message: error.details[0].message
        });
      }

      const { orderId, paymentMethod, paymentDetails } = req.body;

      // Find order
      const order = await Order.findByPk(orderId);
      if (!order) {
        return res.status(404).json({
          success: false,
          message: 'Order not found'
        });
      }

      // Here you would typically integrate with a payment gateway
      // For this example, we'll simulate payment processing
      const paymentSuccessful = simulatePaymentProcessing(paymentMethod, paymentDetails);

      if (paymentSuccessful) {
        order.paymentStatus = 'approved';
        order.status = 'confirmed';
        await order.save();

        return res.json({
          success: true,
          message: 'Payment processed successfully',
          order: {
            id: order.id,
            status: order.status,
            paymentStatus: order.paymentStatus
          }
        });
      } else {
        order.paymentStatus = 'rejected';
        await order.save();

        return res.status(400).json({
          success: false,
          message: 'Payment failed'
        });
      }
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: 'Error processing payment',
        error: error.message
      });
    }
  }
};

// Simulate payment processing
function simulatePaymentProcessing(paymentMethod, details) {
  // In a real application, this would integrate with a payment gateway
  // For demo purposes, we'll return true 90% of the time
  return Math.random() < 0.9;
}

module.exports = paymentController;