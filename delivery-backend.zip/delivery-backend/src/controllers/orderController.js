const Order = require('../models/Order');
const OrderItem = require('../models/OrderItem');
const sequelize = require('../config/database');

const orderController = {
  async create(req, res) {
    const t = await sequelize.transaction();
    
    try {
      const { items, deliveryAddress, paymentMethod, total } = req.body;
      const userId = req.user.id; // Assuming user is authenticated

      // Create the order
      const order = await Order.create({
        userId,
        deliveryAddress,
        paymentMethod,
        total,
        status: 'pending'
      }, { transaction: t });

      // Create order items
      await Promise.all(
        items.map(item => 
          OrderItem.create({
            orderId: order.id,
            productId: item.productId,
            quantity: item.quantity,
            price: item.price
          }, { transaction: t })
        )
      );

      await t.commit();

      return res.status(201).json({
        success: true,
        orderId: order.id,
        message: 'Order created successfully'
      });
    } catch (error) {
      await t.rollback();
      return res.status(500).json({
        success: false,
        message: 'Error creating order',
        error: error.message
      });
    }
  },

  async getOrderById(req, res) {
    try {
      const { id } = req.params;
      const order = await Order.findByPk(id, {
        include: [{ model: OrderItem }]
      });

      if (!order) {
        return res.status(404).json({
          success: false,
          message: 'Order not found'
        });
      }

      return res.json({
        success: true,
        order
      });
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: 'Error fetching order',
        error: error.message
      });
    }
  },

  async updateOrderStatus(req, res) {
    try {
      const { id } = req.params;
      const { status } = req.body;

      const order = await Order.findByPk(id);

      if (!order) {
        return res.status(404).json({
          success: false,
          message: 'Order not found'
        });
      }

      order.status = status;
      await order.save();

      return res.json({
        success: true,
        message: 'Order status updated successfully',
        order
      });
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: 'Error updating order status',
        error: error.message
      });
    }
  }
};

module.exports = orderController;