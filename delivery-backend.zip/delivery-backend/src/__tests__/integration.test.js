const request = require('supertest');
const app = require('../server');
const User = require('../models/User');
const Order = require('../models/Order');
const sequelize = require('../config/database');

describe('Authentication', () => {
  beforeAll(async () => {
    await sequelize.sync({ force: true });
  });

  beforeEach(async () => {
    await User.destroy({ where: {} });
  });

  it('should register a new user', async () => {
    const response = await request(app)
      .post('/auth/register')
      .send({
        name: 'Test User',
        email: 'test@example.com',
        password: 'password123',
        role: 'customer'
      });

    expect(response.status).toBe(201);
    expect(response.body.success).toBe(true);
    expect(response.body.user).toHaveProperty('id');
    expect(response.body).toHaveProperty('token');
  });

  it('should login existing user', async () => {
    // First create a user
    await User.create({
      name: 'Test User',
      email: 'test@example.com',
      password: 'password123'
    });

    const response = await request(app)
      .post('/auth/login')
      .send({
        email: 'test@example.com',
        password: 'password123'
      });

    expect(response.status).toBe(200);
    expect(response.body.success).toBe(true);
    expect(response.body).toHaveProperty('token');
  });
});

describe('Orders', () => {
  let token;
  let user;

  beforeAll(async () => {
    await sequelize.sync({ force: true });
    
    // Create a test user
    user = await User.create({
      name: 'Test User',
      email: 'test@example.com',
      password: 'password123'
    });

    // Generate token
    token = jwt.sign(
      { id: user.id },
      process.env.JWT_SECRET || 'default_secret'
    );
  });

  beforeEach(async () => {
    await Order.destroy({ where: {} });
  });

  it('should create a new order', async () => {
    const response = await request(app)
      .post('/orders')
      .set('Authorization', `Bearer ${token}`)
      .send({
        items: [
          {
            productId: 1,
            quantity: 2,
            price: 10.99
          }
        ],
        deliveryAddress: '123 Test St',
        paymentMethod: 'credit_card',
        total: 21.98
      });

    expect(response.status).toBe(201);
    expect(response.body.success).toBe(true);
    expect(response.body).toHaveProperty('orderId');
  });
});

describe('Payments', () => {
  let token;
  let user;
  let order;

  beforeAll(async () => {
    await sequelize.sync({ force: true });
    
    user = await User.create({
      name: 'Test User',
      email: 'test@example.com',
      password: 'password123'
    });

    token = jwt.sign(
      { id: user.id },
      process.env.JWT_SECRET || 'default_secret'
    );

    order = await Order.create({
      userId: user.id,
      total: 29.99,
      deliveryAddress: '123 Test St',
      paymentMethod: 'credit_card',
      status: 'pending'
    });
  });

  it('should process payment successfully', async () => {
    const response = await request(app)
      .post('/payments')
      .set('Authorization', `Bearer ${token}`)
      .send({
        orderId: order.id,
        paymentMethod: 'credit_card',
        paymentDetails: {
          cardNumber: '4111111111111111',
          cardHolder: 'Test User',
          expirationDate: '12/25',
          cvv: '123'
        }
      });

    expect(response.status).toBe(200);
    expect(response.body.success).toBe(true);
    expect(response.body.order.paymentStatus).toBe('approved');
  });
});