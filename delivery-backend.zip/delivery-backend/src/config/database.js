const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('20252_prjint5', '20252_prjint5', 'Senac@2025', {
  host: 'edumysql.acesso.rj.senac.br',
  dialect: 'mysql',
  logging: false,
  define: {
    timestamps: true,
    underscored: true,
  }
});

module.exports = sequelize;